<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nip' => 'required',
            'password' => 'required',
        ]);
        if ($validator->fails()) {
            return response()
                ->json(['message' => 'Unauthorized'], 401);
        }
        // if (!Auth::attempt($request->only('nip', 'password'))) {
        //     return response()
        //         ->json(['message' => 'Unauthorized'], 401);
        // }
        $user = User::where('nip', $request['nip'])->firstOrFail();
        // $user = User::where('nip', '198807112022031006')->firstOrFail();
        if ($user->password == md5($request['password'])) {
        // if (true) {
            $token = $user->createToken('auth_token')->plainTextToken;
            return response()
                ->json(['id' => $user->id,'level'=>$user->level, 'access_token' => $token, 'token_type' => 'Bearer', 200]);
        } elseif (Auth::attempt($request->only('nip', 'password'))) {
            $token = $user->createToken('auth_token')->plainTextToken;
            return response()
                ->json(['id' => $user->id, 'level' => $user->level, 'access_token' => $token, 'token_type' => 'Bearer', 200]);
        }
        return response()
            ->json(['message' => 'Unauthorized'], 401);
    }

    // method for user logout and delete token
    public function logout()
    {
        auth()->user()->tokens()->delete();

        return [
            'message' => 'You have successfully logged out and the token was successfully deleted'
        ];
    }
}
