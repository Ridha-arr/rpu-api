<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\NonPublish;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class NonPublishController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'judul' => 'required',
            'tahun' => 'required',
            'tempat' => 'required',
            'email' => 'required',
        ]);
        $fileName = '';

        if ($request->hasFile('file')) {
            $fileName = $request->file->store('public/file/nonpublish');
            $fileName = str_replace("public/", "", $fileName);
        }
        NonPublish::create($request->except(['file']) + ['user_id' => auth()->user()->id, 'file' => $fileName]);
        return response()->json(['message' => 'success'], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = NonPublish::where('user_id', $id)->orderBy('tahun', 'DESC')->get();
        return response()->json($data, 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = NonPublish::find($id);
        return response()->json($data, 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $fileName = '';
        $data = NonPublish::find($id);
        $data->update($request->except(['file', 'id']));
        if ($request->hasFile('file')) {
            $file_path = storage_path('app/public/' . $data->file);
            if (File::exists($file_path)) File::delete($file_path);
            $fileName = $request->file->store('public/file/nonpublish');
            $fileName = str_replace("public/", "", $fileName);
            $data->file = $fileName;
            $data->save();
        }
        return response()->json([
            'message' => 'Berhasil Diupdate'
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = NonPublish::find($id);
        $file_path = storage_path('app/public/' . $data->file);
        if (File::exists($file_path)) File::delete($file_path);
        $data->delete();
        return response()->json([
            'message' => 'Berhasil Dihapus'
        ], 200);
    }
}
