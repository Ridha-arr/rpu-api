<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Profile;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class ProfilController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        $data = User::with(['profile', 'biodata', 'prosiding' => function ($query) {
            $query->orderBy('tahun', 'desc');
        }, 'jurnal' => function ($query) {
            $query->orderBy('tahun', 'desc');
        }, 'publikasi', 'workshop' => function ($query) {
            $query->orderBy('tahun', 'desc');
        }, 'buku' => function ($query) {
            $query->orderBy('tahun', 'desc');
        }, 'award' => function ($query) {
            $query->orderBy('tahun', 'desc');
        }])->get();
        return response()->json([
            'user' => User::find($id),
            'profile' => $data->profile,
            'prosiding' => $data->prosiding,
            'jurnal' => $data->jurnal,
            'publikasi' => $data->publikasi,
            'workshop' => $data->workshop,
            'buku' => $data->buku,
            'award' => $data->award
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $profile = Profile::updateOrCreate(['user_id' => auth()->user()->id],$request->except(['image']));
        if ($request->image) {
            $profile = Profile::find($profile->id);
            if (File::exists($profile->foto)) File::delete($profile->foto);
            $fileName = $request->image->store('public/images/' . auth()->user()->id);
            $fileName = str_replace("public/", "storage/", $fileName);
            $profile->foto_fsd = $fileName;
            $profile->save();
        }
        return response()->json($request, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        $data = User::with(['profile', 'biodata'])->where('id', auth()->user()->id)->first();
        return response()->json($data, 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
