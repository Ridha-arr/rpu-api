<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Award;
use App\Models\Buku;
use App\Models\FilePublikasi;
use App\Models\Jurnal;
use App\Models\Karya;
use App\Models\NonPublish;
use App\Models\Opini;
use App\Models\Paten;
use App\Models\Poster;
use App\Models\Profile;
use App\Models\Prosiding;
use App\Models\SdmBiodata;
use App\Models\SdmInstansi;
use App\Models\Seminar;
use App\Models\User;
use App\Models\Workshop;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use phpDocumentor\Reflection\PseudoTypes\LowercaseString;

class DataController extends Controller
{
    public function tahun()
    {
        $data = Jurnal::selectRaw('tahun')->groupByRaw('tahun')->pluck('tahun');
        return response()->json($data, 200);
    }
    public function index()
    {
        $seminar = Seminar::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('user_id', auth()->user()->id)->select(DB::raw('YEAR(tanggal) as tahun'), 'seminars.*')->addSelect(DB::raw("'seminar' as tipe"))->get();
        $buku = Buku::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('user_id', auth()->user()->id)->select('bukus.*')->addSelect(DB::raw("'buku' as tipe"))->get();
        $paten = Paten::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('user_id', auth()->user()->id)->select(DB::raw('YEAR(tanggal) as tahun'), 'patens.*')->addSelect(DB::raw("'paten' as tipe"))->get();
        $jurnal = Jurnal::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('user_id', auth()->user()->id)->select('jurnals.*')->addSelect(DB::raw("'jurnal' as tipe"))->get();
        $prosiding = Prosiding::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('user_id', auth()->user()->id)->select('prosidings.*')->addSelect(DB::raw("'prosiding' as tipe"))->get();
        $nonpublish = NonPublish::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('user_id', auth()->user()->id)->select('non_publishes.*')->addSelect(DB::raw("'laporan' as tipe"))->get();
        $opini = Opini::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('user_id', auth()->user()->id)->select('opinis.*')->addSelect(DB::raw("'opini' as tipe"))->get();
        $karya = Karya::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('user_id', auth()->user()->id)->select('karyas.*')->addSelect(DB::raw("'karya' as tipe"))->get();
        $poster = Poster::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('user_id', auth()->user()->id)->select('posters.*')->addSelect(DB::raw("'poster' as tipe"))->get();
        $data = $seminar->concat($buku);
        $data = $data->concat($paten);
        $data = $data->concat($jurnal);
        $data = $data->concat($prosiding);
        $data = $data->concat($nonpublish);
        $data = $data->concat($opini);
        $data = $data->concat($karya);
        $data = $data->concat($poster);
        $sorted = $data->sortByDesc('tahun')->values();
        return response()->json($sorted, 200);
    }
    public function file(Request $request)
    {
        $fileName = '';
        if ($request->hasFile('file')) {
            $fileName = $request->file->store('public/file/' . $request->tipe . '/' . $request->column);
            $fileName = str_replace("public/", "", $fileName);
            FilePublikasi::create([
                'table_id' => $request->table_id,
                'publikasi' => $request->tipe,
                'jenis' => $request->column,
                'file' => $fileName
            ]);
            return response()->json([
                'message' => 'success'
            ], 200);
        }
    }
    public function GrafikJurnal($state, $year, $value = null, $fakultasNama = null, $prodiNama = null)
    {
        $fakultas = SdmInstansi::where('nama', 'like', 'fakultas%')->pluck('nama');
        $tahun = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->selectRaw('tahun')->groupByRaw('tahun')->pluck('tahun');
        if ($state == 'tahunan') {
            $data = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->selectRaw('count(*) as count,tahun')->groupByRaw('tahun')->pluck('count', 'tahun');
            return response()->json(['jurnal' => $data, 'tahun' => $tahun, 'fakultas' => $fakultas], 200);
        } else if ($state == 'jenis') {
            if ($value == 'semua') {
                $dataJib = [];
                $dataJnt = [];
                $dataJnissn = [];
                $dataJi = [];
                $jib = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->selectRaw('count(*) as count,tahun')->where('jenis', 'JIB')
                    ->groupByRaw('tahun')
                    ->pluck('count', 'tahun');
                $jnt = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->selectRaw('count(*) as count,tahun')->where('jenis', 'JNT')
                    ->groupByRaw('tahun')
                    ->pluck('count', 'tahun');
                $jnissn = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->selectRaw('count(*) as count,tahun')->where('jenis', 'jnissn')
                    ->groupByRaw('tahun')
                    ->pluck('count', 'tahun');
                $ji = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->selectRaw('count(*) as count,tahun')->where('jenis', 'JI')
                    ->groupByRaw('tahun')
                    ->pluck('count', 'tahun');
                foreach ($tahun as $item) {
                    if (isset($jib[$item])) {
                        $dataJib[$item] = $jib[$item];
                    } else {
                        $dataJib[$item] = 0;
                    }
                    if (isset($jnt[$item])) {
                        $dataJnt[$item] = $jnt[$item];
                    } else {
                        $dataJnt[$item] = 0;
                    }
                    if (isset($jnissn[$item])) {
                        $dataJnissn[$item] = $jnissn[$item];
                    } else {
                        $dataJnissn[$item] = 0;
                    }
                    if (isset($ji[$item])) {
                        $dataJi[$item] = $ji[$item];
                    } else {
                        $dataJi[$item] = 0;
                    }
                }
                return response()->json(['jib' => $dataJib, 'jnt' => $dataJnt, 'jnissn' => $dataJnissn, 'ji' => $dataJi, 'tahun' => $tahun, 'fakultas' => $fakultas], 200);
            } else if($fakultasNama){
                if ($fakultasNama) {
                    $fakultasKode = SdmInstansi::where('nama', $fakultasNama)->first();
                }
                if ($prodiNama) {
                    $prodiKode = SdmInstansi::where('nama', $prodiNama)->first();
                }
                $data = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->selectRaw('count(*) as count,tahun,jenis')->where('jenis', $value)->whereHas('user', function ($q) use ($fakultasKode, $prodiKode) {
                    $q->whereHas('biodata', function ($b) use ($fakultasKode, $prodiKode) {
                        $b->whereHas('instansi', function ($i) use ($fakultasKode, $prodiKode) {
                            if ($prodiKode) {
                                $i->where('kode', $prodiKode->kode);
                            } else {
                                $i->where('kode', $fakultasKode->kode);
                            }
                        });
                    });
                })
                    ->groupByRaw('tahun')
                    ->pluck('count', 'tahun');
                return response()->json(['data' => $data, 'tahun' => $tahun, 'fakultas' => $fakultas], 200);
            }else{
                $data = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->selectRaw('count(*) as count,tahun,jenis')->where('jenis', $value)
                    ->groupByRaw('tahun')
                    ->pluck('count', 'tahun');
                return response()->json(['data' => $data, 'tahun' => $tahun, 'fakultas' => $fakultas], 200);
            }
        } else if ($state == 'fakultas') {
            if ($value == 'semua') {
                $hukumData = [];
                $ekonomiData = [];
                $pertanianData = [];
                $fkipData = [];
                $teknikData = [];
                $hukum = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->whereHas('user', function ($q) {
                    $q->whereHas('biodata', function ($b) {
                        $b->whereHas('instansi', function ($i) {
                            $i->where('kode_skpd', '02');
                        });
                    });
                })->selectRaw('count(*) as count,tahun')->groupByRaw('tahun')->pluck('count', 'tahun');
                $ekonomi = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->whereHas('user', function ($q) {
                    $q->whereHas('biodata', function ($b) {
                        $b->whereHas('instansi', function ($i) {
                            $i->where('kode_skpd', '03');
                        });
                    });
                })->selectRaw('count(*) as count,tahun')->groupByRaw('tahun')->pluck('count', 'tahun');
                $pertanian = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->whereHas('user', function ($q) {
                    $q->whereHas('biodata', function ($b) {
                        $b->whereHas('instansi', function ($i) {
                            $i->where('kode_skpd', '04');
                        });
                    });
                })->selectRaw('count(*) as count,tahun')->groupByRaw('tahun')->pluck('count', 'tahun');
                $fkip = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->whereHas('user', function ($q) {
                    $q->whereHas('biodata', function ($b) {
                        $b->whereHas('instansi', function ($i) {
                            $i->where('kode_skpd', '05');
                        });
                    });
                })->selectRaw('count(*) as count,tahun')->groupByRaw('tahun')->pluck('count', 'tahun');
                $teknik = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->whereHas('user', function ($q) {
                    $q->whereHas('biodata', function ($b) {
                        $b->whereHas('instansi', function ($i) {
                            $i->where('kode_skpd', '06');
                        });
                    });
                })->selectRaw('count(*) as count,tahun')->groupByRaw('tahun')->pluck('count', 'tahun');
                foreach ($tahun as $item) {
                    if (isset($hukum[$item])) {
                        $hukumData[$item] = $hukum[$item];
                    } else {
                        $hukumData[$item] = 0;
                    }
                    if (isset($ekonomi[$item])) {
                        $ekonomiData[$item] = $ekonomi[$item];
                    } else {
                        $ekonomiData[$item] = 0;
                    }
                    if (isset($pertanian[$item])) {
                        $pertanianData[$item] = $pertanian[$item];
                    } else {
                        $pertanianData[$item] = 0;
                    }
                    if (isset($fkip[$item])) {
                        $fkipData[$item] = $fkip[$item];
                    } else {
                        $fkipData[$item] = 0;
                    }
                    if (isset($teknik[$item])) {
                        $teknikData[$item] = $teknik[$item];
                    } else {
                        $teknikData[$item] = 0;
                    }
                }
                return response()->json(['hukum' => $hukumData, 'fkip' => $fkipData, 'teknik' => $teknikData, 'ekonomi' => $ekonomiData, 'pertanian' => $pertanianData, 'tahun' => $tahun, 'fakultas' => $fakultas, 'prodi' => []], 200);
            } else {
                $kode = SdmInstansi::where('nama', $value)->first();
                $prodi = SdmInstansi::where('nama', 'not like', 'fakultas%')->where('kode_skpd', $kode->kode_skpd)->pluck('nama');
                $data = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)->whereHas('user', function ($q) use ($kode) {
                    $q->whereHas('biodata', function ($b) use ($kode) {
                        $b->whereHas('instansi', function ($i) use ($kode) {
                            $i->where('kode_skpd', $kode->kode_skpd);
                        });
                    });
                })->selectRaw('count(*) as count,tahun')->groupByRaw('tahun')->pluck('count', 'tahun');
            }
            return response()->json(['data' => $data, 'tahun' => $tahun, 'fakultas' => $fakultas, 'prodi' => $prodi], 200);
        } else if ($state == 'prodi') {
            // $kode = SdmInstansi::where('nama',$value)->first();
            // $data = Jurnal::where('tahun', '>=', $year)->where('tahun', '>=', $year - 5)->whereHas('user', function ($q) use ($kodeFakultas) {
            //     $q->whereHas('biodata', function ($b) use ($kodeFakultas) {
            //         $b->where('instansi', $kodeFakultas->kode);
            //     });
            // })->get();
            $kode = SdmInstansi::where('nama', $value)->first();
            $data = Jurnal::where('tahun', '<=', $year)->where('tahun', '>', $year - 5)
                ->whereHas('user', function ($q) use ($kode) {
                    $q->whereHas('biodata', function ($b) use ($kode) {
                        $b->where('instansi', $kode->kode);
                    });
                })->selectRaw('count(*) as count,tahun')->pluck('count', 'tahun');
            return response()->json(['prodi' => $data, 'tahun' => $tahun, 'fakultas' => $fakultas], 200);
        }
    }
    public function public()
    {
        $akun = Profile::count();
        $scopus = Profile::whereNotNull('scopus')->where('scopus', '!=', '')->count();
        $thomson = Profile::whereNotNull('thomson')->where('thomson', '!=', '')->count();
        $google = Profile::whereNotNull('google')->where('google', '!=', '')->count();
        $sinta = Profile::whereNotNull('sinta')->where('sinta', '!=', '')->count();
        return response()->json(['akun' => $akun, 'scopus' => $scopus, 'thomson' => $thomson, 'sinta' => $sinta, 'google' => $google]);
    }
    public function repo()
    {
        $data = SdmBiodata::selectRaw('nip,instansi,nama,gelar_belakang,gelar_depan')->orderBy('nama')->addSelect([
            'fakultas' => SdmInstansi::selectRaw("(CASE WHEN kode_skpd='02' THEN 'FH' WHEN kode_skpd='03' THEN 'FE' WHEN kode_skpd='04' THEN 'FP' WHEN kode_skpd='05' THEN 'FKIP' WHEN kode_skpd='06' THEN 'FT' ELSE 'S' END) as fakultas")
                ->whereColumn('m_instansi.kode', 'biodata_pegawai.instansi')
        ])->with(['user:nama,id,nip', 'user.profile:user_id,fokus,scopus,thomson,google,sinta'])->whereHas('user.profile')->get();
        // $data = User::with(['biodata.instansi' => function ($q) {
        //         $q->selectRaw("(CASE WHEN kode_skpd='02' THEN 'FH' WHEN kode_skpd='03' THEN 'FE' WHEN kode_skpd='04' THEN 'FP' WHEN kode_skpd='05' THEN 'FKIP' WHEN kode_skpd='06' THEN 'FT' ELSE 'S' END) as fakultas");
        //         // if ($i->kode_skpd == '02') {
        //         //     return 'FH';
        //         // } else if ($i->kode_skpd == '03') {
        //         //     return 'FE';
        //         // } else if ($i->kode_skpd == '04') {
        //         //     return 'FP';
        //         // } else if ($i->kode_skpd == '05') {
        //         //     return 'FKIP';
        //         // } else if ($i->kode_skp == '06') {
        //         //     return 'FT';
        //         // }
        // }])->whereHas('profile')->where('level', '3')->get();
        return response()->json($data, 200);
    }
    public function cari($search)
    {
        $seminar = Seminar::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('nama', 'like', '%' . $search . '%')->orWhere('judul', 'like', '%' . $search . '%')->select('seminars.*')->addSelect(DB::raw("'seminar' as tipe"))->get();
        $jurnal = Jurnal::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('nama', 'like', '%' . $search . '%')->orWhere('judul', 'like', '%' . $search . '%')->select('jurnals.*')->addSelect(DB::raw("'jurnal' as tipe"))->get();
        $prosiding = Prosiding::with(['fileReview', 'fileTurnitin', 'fileKoresponden'])->where('nama', 'like', '%' . $search . '%')->orWhere('judul', 'like', '%' . $search . '%')->select('prosidings.*')->addSelect(DB::raw("'prosiding' as tipe"))->get();
        $data = $seminar->concat($jurnal);
        $data = $data->concat($prosiding);
        $sorted = $data->sortBy('nama')->values();
        return response()->json($sorted, 200);
    }
    public function user($nama)
    {
        $nama = str_replace('_', ' ', $nama);
        $data = User::with(['profile', 'biodata.instansi', 'biodata:tempat_lahir,nidon,instansi,nip,nama,gelar_depan,gelar_belakang,tanggal_lahir', 'pendidikan_s1', 'pendidikan_s2', 'pendidikan_s3'])
            ->where('nama', $nama)->with(['profile', 'biodata'])->first();
        return response()->json($data, 200);
    }
    public function publikasi($nama, $publikasi)
    {
        $nama = str_replace('_', ' ', $nama);
        $user = User::whereRaw('LOWER(`nama`) = ', trim(strtolower($nama)))->first();
        if ($publikasi == 'Jurnal') {
            $data = Jurnal::where(['user_id' => $user->id])->select('jurnals.*')->addSelect(DB::raw("'jurnal' as tipe"))->orderBy('tahun', 'DESC')->get();
        } else if ($publikasi == 'Prosiding') {
            $data = Prosiding::where(['user_id' => $user->id])->select('prosidings.*')->addSelect(DB::raw("'prosiding' as tipe"))->orderBy('tahun', 'DESC')->get();
        } else if ($publikasi == 'Workshop') {
            $data = Workshop::where(['user_id' => $user->id])->select(DB::raw('YEAR(tanggal) as tahun,workshops.*'))->addSelect(DB::raw("'workshop' as tipe"))->orderBy('tanggal', 'DESC')->get();
        } else if ($publikasi == 'Buku') {
            $data = Buku::where(['user_id' => $user->id])->select('bukus.*')->addSelect(DB::raw("'buku' as tipe"))->orderBy('tahun', 'DESC')->get();
        } else if ($publikasi == 'Award') {
            $data = Award::where(['user_id' => $user->id])->select(DB::raw('YEAR(tanggal) as tahun,awards.*'))->addSelect(DB::raw("'award' as tipe"))->orderBy('tanggal', 'DESC')->get();
        }
        return response()->json($data, 200);
    }
}
