<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Buku;
use App\Models\FilePublikasi;
use App\Models\Jurnal;
use App\Models\Karya;
use App\Models\NonPublish;
use App\Models\Opini;
use App\Models\Paten;
use App\Models\Poster;
use App\Models\Prosiding;
use App\Models\Seminar;
use App\Models\User;
use App\Models\Verifikasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReviewerController extends Controller
{
    public function index()
    {
        $data = User::where('level', 3)->get();
        return response()->json($data, 200);
    }
    public function view($id)
    {
        $seminar = Seminar::with(['fileReview', 'fileTurnitin', 'fileKoresponden','verifikasi'])->where('user_id', $id)->select(DB::raw('YEAR(tanggal) as tahun'), 'seminars.*')->addSelect(DB::raw("'seminar' as tipe"))->get();
        $buku = Buku::with(['fileReview', 'fileTurnitin', 'fileKoresponden','verifikasi'])->where('user_id', $id)->select('bukus.*')->addSelect(DB::raw("'buku' as tipe"))->get();
        $paten = Paten::with(['fileReview', 'fileTurnitin', 'fileKoresponden','verifikasi'])->where('user_id', $id)->select(DB::raw('YEAR(tanggal) as tahun'), 'patens.*')->addSelect(DB::raw("'paten' as tipe"))->get();
        $jurnal = Jurnal::with(['fileReview', 'fileTurnitin', 'fileKoresponden','verifikasi'])->where('user_id', $id)->select('jurnals.*')->addSelect(DB::raw("'jurnal' as tipe"))->get();
        $prosiding = Prosiding::with(['fileReview', 'fileTurnitin', 'fileKoresponden','verifikasi'])->where('user_id', $id)->select('prosidings.*')->addSelect(DB::raw("'prosiding' as tipe"))->get();
        $nonpublish = NonPublish::with(['fileReview', 'fileTurnitin', 'fileKoresponden','verifikasi'])->where('user_id', $id)->select('non_publishes.*')->addSelect(DB::raw("'laporan' as tipe"))->get();
        $opini = Opini::with(['fileReview', 'fileTurnitin', 'fileKoresponden','verifikasi'])->where('user_id', $id)->select('opinis.*')->addSelect(DB::raw("'opini' as tipe"))->get();
        $karya = Karya::with(['fileReview', 'fileTurnitin', 'fileKoresponden','verifikasi'])->where('user_id', $id)->select('karyas.*')->addSelect(DB::raw("'karya' as tipe"))->get();
        $poster = Poster::with(['fileReview', 'fileTurnitin', 'fileKoresponden','verifikasi'])->where('user_id', $id)->select('posters.*')->addSelect(DB::raw("'poster' as tipe"))->get();
        $data = $seminar->concat($buku);
        $data = $data->concat($paten);
        $data = $data->concat($jurnal);
        $data = $data->concat($prosiding);
        $data = $data->concat($nonpublish);
        $data = $data->concat($opini);
        $data = $data->concat($karya);
        $data = $data->concat($poster);
        $sorted = $data->sortByDesc('tahun')->values();
        return response()->json($sorted, 200);
    }
    public function post(Request $request)
    {

        Verifikasi::create(['table_id' => $request->table_id, 'state' => $request->status]);
        return response()->json(['message'=>'success'], 200);
    }
    public function destroy($id){
        Verifikasi::find($id)->delete();
        return response()->json(['message' => 'success'], 200);
    }
}
